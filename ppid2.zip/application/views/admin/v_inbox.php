 
<!DOCTYPE html>
<html> 
<?php $this->load->view('admin/v_tag_header'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

   <?php
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_menu_sidebar');
  ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        PPID System | Permohonan Informasi Baru
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Permohonan Informasi Baru</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12"> 
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="myTable" class="table-responsive table-striped " style="font-size:12px;">
                <thead>
                <tr> 
                    <th >No</th>
                    <th >Tanggal Terdaftar</th>
					          <th >IDPI</th>
					          <th >NIK/NO_KEMENKUMHAM</th>
					          <th >Pemohon</th> 
                    <th>Permohonan Informasi</th>
                    <th>Tujuan Permohonan</th>
                    <th>Dokumen</th>               
                    <th style="width:100px;">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $no=0;
                    foreach ($data->result_array() as $i) :
  					      $no++; 
                  ?>
                <tr>                  
                  <td style="vertical-align: middle;"><?= $no; ?></td>
                  <td style="vertical-align: middle;"><?= $i['tgl_terdaftar']; ?> </td>
                  <td style="vertical-align: middle;"><?= $i['idpi']; ?> <br> Belum Diproses <br> (Selama, <?= hitung_sejak_belum_diproses($i['tgl_terdaftar']); ?>)</td>
                  <td style="vertical-align: middle;"><?= $i['nik_nokemenkumham']; ?></td>
                  <td style="vertical-align: middle;"><?= $i['nama'];?> <br> <?= $i['alamat'];?> <br> <?= $i['nohp'];?> <br> <?= $i['email'];?></td> 
                  <td style="vertical-align: middle;"><?= $i['mohon_informasi']; ?></td>
                  <td style="vertical-align: middle;"><?= $i['tujuan_informasi']; ?></td> 
                  <?php if($i['gfile']==null):?>
                      <td style="vertical-align: middle;">Tidak ada lampiran</td> 
                  <?php else:?>  
                      <td style="vertical-align: middle;"><a href="<?php echo base_url().'assets/files/'.$i['gfile'];?>" target="_blank">Dokumen</a></td> 
                  <?php endif;?>
                  <td style="vertical-align: middle;">  <a class="popup2 btn-sm btn-danger" data-toggle="modal" data-target="#ModalProses<?= $i['id']; ?>"> <span class="fa fa-gears"></span></a> 
                    <a class="popup2 btn-sm btn-info" data-toggle="modal" data-target="#ModalDisposisi<?= $i['id']; ?>"><span class="fa fa-send"></span> </a> </td>  
                </tr>
				        <?php endforeach;?>
                </tbody>
              </table> 
            </div> 
          </div> 
        </div> 
      </div> 
    </section> 
  </div>
  <!-- /.content-wrapper -->
 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong><?php echo date('Y');?> © Copyright <a href="http://tanjungbalaikota.go.id">Pemerintah Kota Tanjungbalai</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->




  <?php foreach ($data->result_array() as $i) : ?>
  <!--Modal Proses Laporan-->
        <div class="modal fade" id="ModalProses<?php echo $i['id'];?>" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Tindak Lanjut Permohonan Informasi</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/inbox/simpan_progress'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDPI</label>
                        <div class="col-sm-8"> 
                        <input type="text" name="idpi" class="form-control" value="<?php echo $i['idpi'];?>" readonly>
                        </div>
                    </div>
           
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-8"> 
                        <input type="text" name="email" class="form-control" value="<?php echo $i['email'];?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal</label>
                        <div class="col-sm-8">
                       
                        <input type="text" class="form-control" value="<?php echo $i['tanggal'];?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Permohonan Informasi</label>
                        <div class="col-sm-8">
                        <textarea class="form-control" rows="8" cols="80" readonly><?php echo $i['mohon_informasi'];?></textarea>
                        </div>
                  </div>

                  <hr>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> PROGRES LAPORAN PERMOHONAN INFORMASI</label>
                        
                    </div>

                    <div class="form-group">
                      <label for="inputUserName" class="col-sm-3 control-label">Status</label>
                      <div class="col-sm-8">
                        <select class="form-control" name="status" required>
                            <option value="">Pilih Status</option>
                            <option value="1">Setujui</option>
                            <option value="2">Tolak</option>
                        </select>
                      </div>
                    </div> 
                    
                    <div class="form-group">
                      <label for="inputUserName" class="col-sm-3 control-label">Dokumen Informasi</label>
                      <div class="col-sm-8">
                        <select class="form-control select2" style="width: 100%;" name="dokumen">
                            <option value="">Pilih Dokumen </option>
                            <?php 
                            foreach ($dokumen->result_array() as $dk) :   
                            ?>
                            <option value="<?php echo $dk['id'];?>"><?php echo $dk['keterangan']; ?></option>
                            <?php endforeach;?>
                        </select>
                      </div>
                    </div> 

                    <div class="form-group">
                          <label for="inputUserName" class="col-sm-3 control-label">Keterangan</label>
                          <div class="col-sm-8">
                          <textarea name="keterangan" class="form-control" rows="8" cols="80" required></textarea>
                          </div>
                    </div>
 
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan"><span class="fa fa-thumbs-o-up"> </span> Simpan </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>


<?php foreach ($data->result_array() as $i) :  ?>
  <!--Modal Disposisi Laporan-->
        <div class="modal fade" id="ModalDisposisi<?php echo $i['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Teruskan Permohonan Ke OPD</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/inbox/teruskan_permohonan_ke_opd'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDPI</label>
                        <div class="col-sm-8">
                        <input type="hidden" name="idpi" value="<?php echo $i['idpi'];?>"/>  
                        <input type="text" class="form-control" id="inputUserName" value="<?php echo $i['idpi'];?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Lapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="tglterdaftar" class="form-control" id="inputUserName" value="<?php echo $i['tanggal'];?>" readonly>
                        </div>
                    </div> 

                  <hr>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> SILAHKAN TERUSKAN LAPORAN KE OPD </label>
                        
                    </div>

                    <div class="form-group">
                      <label for="inputUserName" class="col-sm-3 control-label">Pilih OPD</label>
                      <div class="col-sm-8">
                        <select class="form-control" name="email" required>
                            <option value="">-Pilih-</option>
                            <?php 
                            foreach ($opd->result_array() as $o) :
                            $no++;
                            $opd_id=$o['opd_id'];
                            $opd_nama=$o['opd_nama'];
                            $opd_email=$o['opd_email'];
                            
                            ?>
                            <option value="<?php echo $opd_email;?>"><?php echo $opd_nama;?></option>
                            <?php endforeach;?>
                        </select>
                      </div>
                  </div> 
                      <div class='alert alert-success'>Catatan: </br>
                      *Petugas Verifikasi diharapkan agar mengupload data dokumen informasi publik, sebelum progress permohon disetujuan dan data dokumen informasi dapat terlihat pada kolom pilih dokumen melalui menu Dokumen Informasi Publik untuk disampaikan ke pemohon informasi </br> 
                      </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-flat" data-dismiss="modal">Close</button>
                        <button onclick="hideButton(this)" type="submit" class="btn btn-primary btn-flat" id="simpan"><span class="fa fa-send"> </span> Kirim </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>

  <?php $this->load->view('admin/v_js'); ?>

</body>
</html>
