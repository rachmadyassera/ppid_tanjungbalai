<?php
class M_kontak extends CI_Model{

	function kirim_pesan($topik,$tglkejadian,$pejabat,$lokasi,$kronologis,$email,$nama,$idwb,$file){
		$hsl=$this->db->query("INSERT INTO tbl_lapor(inbox_topik,inbox_tglkejadian,inbox_kategori_laporan,inbox_lokasi,inbox_kronologis,inbox_nama,inbox_email,inbox_file,inbox_idwb) VALUES ('$topik','$tglkejadian','$pejabat','$lokasi','$kronologis','$nama','$email','$file','$idwb')");
		return $hsl;
	}


	function get_all_inbox(){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor ORDER BY inbox_id DESC");
		return $hsl;
	}

	function get_lapor_byid($id){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor WHERE inbox_id='$id'");
		return $hsl;
	}

	function get_lapor_byidwb($idwb){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor WHERE inbox_idwb='$idwb'");
		return $hsl;
	}

	function get_all_inbox_0(){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor WHERE inbox_tindaklanjut='0' ORDER BY inbox_id DESC");
		return $hsl;
	}

	function get_all_inbox_1(){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor WHERE inbox_tindaklanjut='1' ORDER BY inbox_id DESC");
		return $hsl;
	}

	function get_all_inbox_2(){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor WHERE inbox_tindaklanjut='2' ORDER BY inbox_id DESC");
		return $hsl;
	}

	function get_all_wb(){
		$hsl=$this->db->query("SELECT tbl_lapor.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_lapor ORDER BY inbox_id DESC");
		return $hsl;
	}


	function hapus_kontak($kode){
		$hsl=$this->db->query("DELETE FROM tbl_lapor WHERE inbox_id='$kode'");
		return $hsl;
	}

	function update_status_kontak(){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_status='0'");
		return $hsl;
	}

	function update_status_kontak_0(){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_status='0' WHERE inbox_tindaklanjut='0'");
		return $hsl;
	}

	function update_status_kontak_1(){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_status='0' WHERE inbox_tindaklanjut='1'");
		return $hsl;
	}

	function simpan_penyelidikan($id,$tindaklanjut,$keterangan,$img_1,$img_2,$img_3,$user_nama,$tanggal_verif){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_tindaklanjut='$tindaklanjut',inbox_keterangan='$keterangan',inbox_filetl='$img_1',inbox_filetl2='$img_2',inbox_filetl3='$img_3',inbox_author='$user_nama', inbox_status='1', inbox_tanggal_verif='$tanggal_verif' WHERE inbox_id='$id'");
		return $hsl;
	}

	function simpan_tolak_penyelidikan($id,$tindaklanjut,$keterangan,$user_nama,$tanggal_verif){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_tindaklanjut='$tindaklanjut',inbox_keterangan='$keterangan',inbox_author='$user_nama', inbox_status='1', inbox_tanggal_verif='$tanggal_verif' WHERE inbox_id='$id'");
		return $hsl;
	}
	function batal_penyelidikan($id,$tindaklanjut,$keterangan,$file,$user_nama,$tanggal_verif){
		$hsl=$this->db->query("UPDATE tbl_lapor SET inbox_tindaklanjut='$tindaklanjut',inbox_keterangan='$keterangan',inbox_filetl='$file',inbox_author='$user_nama', inbox_status='1', inbox_tanggal_verif='$tanggal_verif' WHERE inbox_id='$id'");
		return $hsl;
	}
	function ceknik($n){
        $hasil=$this->db->query("SELECT * FROM tbl_capil WHERE nik='$n'");
        return $hasil;
    }
}