<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sikomplit |  Pemerintah Kota Tanjungbalai</title>
    <meta name="description" content=" Selamat Datang di Sistem Komunikasi Pelaporan ter Integrasi Tanjungbalai, Kerahasiaan Identitas Pelapor akan dijamin Oleh Pemerintah Kota Tanjungbalai, Sikomplit System ini disediakan oleh Pemerintah Kota Tanjungbalai bagi anda yang memiliki informasi dan ingin melaporkan suatu pelayanan publik yang terjadi di lingkungan Pemerintah Kota Tanjungbalai" />
    <meta name="keywords" content="Sikomplit, Pelanggaran ASN, Diskominfo Kota Tanjungbalai, Pemerintah Kota Tanjungbalai, Rachmad Yasser Al Zuhri" />
    <meta name="author" content="Dinas Kominfo | Bidang TI - Rachmad Yasser Al Zuhri | rachmad.yasser@gmail.com | 081279329132 " />

    <link rel="shorcut icon" href="<?php echo base_url().'theme/images/icon.png'?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/bootstrap.min.css'?>">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/font-awesome.min.css'?>">
    <!-- Simple Line Font -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/simple-line-icons.css'?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/owl.carousel.min.css'?>">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datepicker/datepicker3.css'?>">
    <!-- Main CSS -->
    <link href="<?php echo base_url().'theme/css/style.css'?>" rel="stylesheet">

    <link href="<?php echo base_url().'theme/css/dataTables.bootstrap4.min.css'?>" rel="stylesheet">
</head>

<body>
  <!--============================= HEADER =============================-->
  <div class="header-topbar">
      <div class="container">
          <div class="row">
              <marquee>
              <div class="col-xs-6 col-sm-8 col-md-9">
                  <div class="header-top_address">
                      <div class="header-top_list">
                      <span></span>Selamat Datang di Sikomplit, Bersama Awasi Infrastruktur, Bantuan Sosial, Pendidikan Dengan Berani Melapor ! Kerahasiaan Identitas Pelapor akan dijamin Oleh Pemerintah Kota Tanjungbalai
                      </div>
                      <div class="header-top_list">
                          <span class="icon-envelope-open"></span>diskominfo@tanjungbalaikota.go.id
                      </div>
                      <div class="header-top_list">
                          <span class="icon-location-pin"></span>Tanjungbalai, Sumatera Utara. 21367
                      </div>
                  </div>
                  <!-- <div class="header-top_login2">
                      <a href="<?php echo site_url('contact');?>">Hubungi Kami</a>
                  </div> -->
              </div>
              </marquee>
          </div>
      </div>
  </div>
  <div data-toggle="affix" style="border-bottom:solid 1px #f2f2f2;">
      <div class="container nav-menu2">
          <div class="row">
              <div class="col-md-12">
                  <nav class="navbar navbar2 navbar-toggleable-md navbar-light bg-faded">
                      <button class="navbar-toggler navbar-toggler2 navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
                          <span class="icon-menu"></span>
                      </button>
                      <a href="<?php echo site_url('');?>" class="navbar-brand nav-brand2"><img class="img img-responsive" width="200px;" src="<?php echo base_url().'theme/images/logo-dark.png'?>"></a>
                  <!--    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">-->
                  <!--        <ul class="navbar-nav">-->
                  <!--            <li class="nav-item">-->
                  <!--              <a class="nav-link" href="https://diskominfo.tanjungbalaikota.go.id/">Portal Diskominfo </a>-->
                  <!--            </li>-->
                  <!--      </ul>-->
                  <!--</div>-->
                </nav>
              </div>
            </div>
          </div>
        </div>
    <section>
</section>

<!--============================= ABOUT =============================-->
<!--<section class="clearfix about about-style2">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-md-8">-->
<!--               <h2>Tanjungbalai Sikomplit System</h2>-->
<!--               <justify><p>Tanjungbalai Sikomplit System ini disediakan oleh Pemerintah Kota Tanjungbalai bagi anda yang memiliki informasi dan ingin melaporkan terkait infrastruktur jalan, bantuan sosial, serta pendidikan di lingkungan Pemerintah Kota Tanjungbalai</p></justify>-->
<!--            </div>-->
<!--            <div class="col-md-3">-->
<!--                <img src="<?php echo base_url().'theme/images/logo-pemko.png'?>" class="img-fluid about-img" width="1000" height="1200" alt="#">-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</br>-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-md-3">-->
<!--                <img src="<?php echo base_url().'theme/images/peluit-2.jpg'?>" class="img-fluid about-img" alt="#">-->
<!--              </br>-->
<!--            </div>-->
<!--          </br>-->
<!--            <div class="col-md-8">-->

               
<!--               <h2>Sikomplit</h2>-->
<!--               <p>Sikomplit adalah Sistem Komunikasi Pemerintah Laporan terIntegrasi yang bertujuan sebagai penjembatan masyarakat dengan pemerintah dalam hal pelaporan terkait infrastuktur jalan, bantuan sosial, serta pendidikan yang akan ditindak lanjuti oleh pemerintah kota Tanjungbalai .</p>-->
<!--               </div>-->
            
<!--        </div>-->
<!--    </div>-->
<!--</section>-->
<!--//END ABOUT -->
<!--//END HEADER -->
<section class="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="contact-title">
                    <h2>Formulir Pengaduan Anda</h2>
                </div>
                <div><?php echo $this->session->flashdata('msg');?></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="contact-form">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-6 contact-option">
                            <div class="contact-option_rsp">
                                <h3><i class="fa fa-comments" aria-hidden="true"></i> Isi Laporan Anda !</h3>
                                <form action="<?php echo site_url('contact/kirim_pesan');?>" method="post" enctype="multipart/form-data">

                                  <div class="contact-details">
                                    <i class="" aria-hidden="true">Judul Pengaduan Anda</i>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Topik Pengaduan.." name="xtopik" required="" oninvalid="this.setCustomValidity('Mohon Mengisi Topik Pengaduan Anda !')">
                                    </div>

                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Tanggal Kejadian </i>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group date">
                                        <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" name="xtglkejadian" class="form-control pull-right" id="datepicker" required>
                                        </div>
                                    </div>

                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Jenis Laporan anda </i>
                                    </div>
                                    <div class="form-group">
                                        <select class="form-control" name="xpejabat" required>
                                                <option value='Administrasi Data Penduduk'>Administrasi Penduduk</option>
                                                <option value='Administrasi Data Penduduk'>Sosial</option>
                                                <option value='Administrasi Data Penduduk'>Pendidikan</option>
                                                <option value='Administrasi Data Penduduk'>Kesehatan</option>
                                                <option value='Administrasi Data Penduduk'>Perhubungan</option>
                                                <option value='Administrasi Data Penduduk'>Komunikasi dan Informasi Publik</option>
                                                <option value='Administrasi Data Penduduk'>Keamanan dan Ketertiban</option>
                                                
                                            </select>
                                    </div>
                                    <!-- // end .form-group -->

                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Lokasi Kejadian </i>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Lokasi Kejadian.." name="xlokasi" required="" oninvalid="this.setCustomValidity('Lokasi Kejadian Harus di isi!')">
                                    </div>
                                    <!-- // end .form-group -->

                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Uraian Kronologis Kejadian</i>
                                    </div>
                                   <textarea placeholder="Uraian Kejadian.." class="form-control" name="xkronologis" required="" oninvalid="this.setCustomValidity('Kronologis Kejadian Harus di isi dan detail !')" rows="10"></textarea>
                                    <!-- // end .form-group -->

                                  </br>
                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Email Anda </br>( Tindak Lanjut Laporan Anda Akan dikirim ke Email )</i>
                                    </div>
                                    <div class="form-group">
                                        <input type="email.." class="form-control" placeholder="Email" name="xemail" required="" oninvalid="this.setCustomValidity('Email Anda Harus di isi atau format salah, ( contoh : diskominfo@gmail.com)!')">
                                    </div>
                                    <!-- // end .form-group -->
                                    <?php
                                        $nik=$this->session->userdata('nik');
                                        $q=$this->db->query("SELECT * FROM tbl_capil WHERE nik='$nik'");
                                        $c=$q->row_array();
                                    ?>
                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Nama Anda ( Identitas Pelapor Akan Dirahasiakan dan Dijamin Oleh Pemerintah Kota Tanjungbalai ) </i>
                                    </div>
                                    <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Nama Anda.." name="xnama" value="<?php echo $c['nama_pelapor'];?>" readonly>
                                    </div>
                                    <!-- // end .form-group -->
                                    <?php
                                    $wb=rand(0000000,9999999);
                                    $getidwb=$wb;
                                    ?>

                                     <div class="contact-details">
                                    <i class="" aria-hidden="true">#Kode Sikomplit Anda ( Simpan Kode dibawah ini, sebagai Bukti / No Lapor Anda ) </i>
                                    </div>
                                    <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Nama Anda.." name="xidwb" value=" IDSK-<?php echo $getidwb;?>" readonly>
                                    </div>
                                    <!-- // end .form-group -->

                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">Upload Bukti Pendukung</i>
                                    </div>
                                    <div class="form-group">
                                    <input type="file" class="form-control" placeholder="Photo.." name="xfile">
                                    </div>
                                    <div class="contact-details">
                                    <i class="" aria-hidden="true">* Format File dalam bentuk ( jpg, jpeg, png, mp4, atau lebih dari satu, kumpulkan dalam bentuk rar, atau Zip dengan max size file 10 MB )</i>
                                    </div>
                                    
                                    <!-- // end .form-group -->

                                    <button type="submit" class="btn btn-default btn-submit">KIRIM LAPORAN</button>
                                     </br>
                                      <div class="contact-details">
                                      </br>
                                      
                                      </div>
                                    <!-- // end #js-contact-result -->
                                </form>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-6">
                            <div class="contact-address">
                                <h3> <i class="fa fa-check" aria-hidden="true"></i> Unsur Pengaduan </h3>
                                </br>
                                <div class="contact-details">
                                    <h4><i class="fa fa-question-circle" aria-hidden="true"></i>
                                    &nbsp;&nbsp;What (Apa?)</h4>
                                    <p>Laporan berindikasi pelanggaran yang diketahui </p>
                                    </div>
                                    <br>
                                    <div class="contact-details">
                                    <h4><i class="fa fa-map-marker" aria-hidden="true"></i>
                                    &nbsp;&nbsp;Where (Dimana?)</h4>
                                    <p>Dimana lokasi tersebut terjadi</p>
                                    </div>
                                    <br>
                                    <div class="contact-details">
                                    <h4><i class="fa fa-clock-o" aria-hidden="true"></i>
                                    &nbsp;&nbsp;When (Kapan?)</h4>
                                    <p>Kapan perbuatan tersebut terjadi</p>
                                    </div>
                                    <br>
                                    <div class="contact-details">
                                    <h4><i class="fa fa-users" aria-hidden="true"></i>
                                    &nbsp;&nbsp;Who (Siapa?)</h4>
                                    <p>Siapa saja yang terlibat dalam perbuatan tersebut</p>
                                    </div>
                                    <br>
                                    <div class="contact-details">
                                    <h4><i class="fa fa-clock-o" aria-hidden="true"></i>
                                    &nbsp;&nbsp;How (Bagaimana?)</h4>
                                    <p>Bagaimana perbuatan tersebut dilakukan (modus,cara,dsb)</p>
                                    </br>

                                    <h3><i class="fa fa-lock" aria-hidden="true"> </i>&nbsp Kerahasiaan Dijamin </h3>
                                    <div class="contact-details" style="text-align:justify;">
                                    <p>Untuk anda yang ingin melaporkan tapi merasa sungkan atau takut identitasnya anda terungkap, anda bisa menggunakan fasilitas ini. Anda bisa melaporkan dengan melalui Sikomplit, kerahasiaan identitas anda akan dijamin oleh Pemerintah Kota Tanjungbalai</p>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </br>
           

        </div>
        </br>
    </section>

    <section class="contact" style="margin-bottom:50px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="contact-title">
                    <h2>Pencarian Hasil Laporan</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <table class="table table-striped" id="display">
                  <thead>
                    <tr>
                      <th style="text-align:left; width:100px;">IDSK</th>
                      
                      <th>Tindak Lanjut</th>
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $no=1;
                      foreach ($data->result() as $row):
                    ?>
                    <tr>
                      <td><?php echo $row->inbox_idwb?></td>
                      
                      <?php if($row->inbox_tindaklanjut=='0'):?>
                      <td>Laporan diterima dan sedang di proses.</td>
                      <?php elseif($row->inbox_tindaklanjut=='1'):?>
                      <td>Penyelidikan Selesai, Hasil Laporan Akan Segera dikirim ke email Anda.</td>
                      <?php elseif($row->inbox_tindaklanjut=='2'):?>
                      <td>Laporan Anda di Tolak</td>
                      <?php endif;?>
                      
                    </tr>
                  <?php endforeach;?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </br>
        <div class="form-group">
        </div>

         <!--  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.5064515293493!2d99.79249771468095!3d2.95687479784648!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x303251d78d775a9b%3A0x901381b6c8fe85af!2sInspektorat%20Kota%20Tanjungbalai!5e0!3m2!1sid!2sid!4v1571130437232!5m2!1sid!2sid" width="1110" height="750" frameborder="0" style="border:0;" allowfullscreen=""></iframe> -->
        </div>
       
    </section>
  
    <!--//END  ABOUT IMAGE -->
    <!--============================= FOOTER =============================-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="foot-logo">
                        <a href="<?php echo site_url();?>">
                            <img src="<?php echo base_url().'theme/images/logo-dark.png'?>" class="img-fluid" alt="footer_logo">
                        </a>
                        <p><?php echo date('Y');?> © copyright by <a href="http://diskominfo.tanjungbalaikota.go.id" target="_blank">Diskominfo Kota Tanjungbalai - Sumatera Utara</a>. <br>All rights reserved.</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="address">
                            <h3>Support By</h3>
                            
                            <p><a href="http://diskominfo.tanjungbalaikota.go.id" target="_blank"> Dinas Komunikasi dan Informatika Kota Tanjungbalai</a>
                              </p>
                            </div>
                        </div>
                        <div class="col-md-3">
                        <div class="address">
                            <h3>Portal Resmi</h3>
                            <li><a href="http://diskominfo.tanjungbalaikota.go.id" target="_blank"> Diskominfo Kota Tanjungbalai</a></li>
                            <li><a href="http://tanjungbalaikota.go.id/web" target="_blank"> Pemerintah Kota Tanjungbalai</a></li>
                            </div>
                        </div>
                    <div class="col-md-3">
                        <div class="address">
                            <h3>Hubungi Kami</h3>
                            <p><span>Alamat: </span> Jl. Jend. Sudirman, Km. 5.5, Kel. Sijambi , Kec. Datuk Bandar, Kota Tanjungbalai</p>
                            <p>Email : diskominfo@tanjungbalaikota.go.id
                                <br></p>
                           
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!--//END FOOTER -->

            <!-- jQuery, Bootstrap JS. -->
            <script src="<?php echo base_url().'theme/js/jquery.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/tether.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/bootstrap.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/owl.carousel.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/validate.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/tweetie.min.js'?>"></script>
            <!-- Subscribe / Contact-->
            <script src="<?php echo base_url().'theme/js/subscribe.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/contact.js'?>"></script>
            <!-- Script JS -->
            <script src="<?php echo base_url().'theme/js/script.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/jquery.dataTables.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/dataTables.bootstrap4.min.js'?>"></script>
            <!-- SlimScroll -->
            <script src="<?php echo base_url().'assets/plugins/slimScroll/jquery.slimscroll.min.js'?>"></script>
            <script src="<?php echo base_url().'assets/plugins/datepicker/bootstrap-datepicker.js'?>"></script>
            <script src="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.js'?>"></script>
            <script src="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.js'?>"></script>


            <script>


              $(document).ready(function() {
                $('#display').DataTable();
                // "sSearch": " Cari Dengan IDWB Anda"
              });

              $('#datepicker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
              });
              $('#datepicker2').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
              });
              $('.datepicker3').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
              });
              $('.datepicker4').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
              });
              $(".timepicker").timepicker({
                showInputs: true
              });
            </script>
        </body>

        </html>
