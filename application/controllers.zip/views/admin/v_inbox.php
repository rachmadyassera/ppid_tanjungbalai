<!--Counter Inbox-->
<?php
    $query=$this->db->query("SELECT * FROM tbl_inbox WHERE inbox_status='1'");
    $query2=$this->db->query("SELECT * FROM tbl_komentar WHERE komentar_status='0'");
    $jum_comment=$query2->num_rows();
    $jum_pesan=$query->num_rows();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sikomplit System | Pengaduan Baru</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="shorcut icon" type="text/css" href="<?php echo base_url().'theme/images/icon.png'?>">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css'?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css'?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/AdminLTE.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.css'?>">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datepicker/datepicker3.css'?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/skins/_all-skins.min.css'?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.css'?>"/>

</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

   <?php
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_menu_sidebar');
  ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sikomplit System | Pengaduan Baru
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pengaduan Baru</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:12px;">
                <thead>
                <tr>

                    <th style="width:100px;">Tanggal Lapor</th>
					          <th style="width:120px;">ID Sikomplit</th>
                    <th style="width:320px;">Topik Laporan</th>
                    <th>Nama Pelapor</th>
                    <th style="width:120px;">Penyelidikan Dibatalkan Oleh</th>
                    
                    <th style="text-align:center; width:130px;">Aksi</th>
                </tr>
                </thead>
                <tbody>
				<?php
					$no=0;
  					foreach ($data->result_array() as $i) :
  					      $no++;
                   $inbox_id=$i['inbox_id'];
                   $inbox_idwb=$i['inbox_idwb'];
                   $inbox_topik=$i['inbox_topik'];
                   $inbox_tglkejadian=$i['inbox_tglkejadian'];
                   $inbox_pejabat=$i['inbox_kategori_laporan'];
                   $inbox_lokasi=$i['inbox_lokasi'];
                   $inbox_kronologis=$i['inbox_kronologis'];
                   $inbox_nama=$i['inbox_nama'];
                   $inbox_file=$i['inbox_file'];
                   $inbox_author=$i['inbox_author'];
                   $tanggal_verif=$i['inbox_tanggal_verif'];
                   $tanggal=$i['tanggal'];
                    ?>
                <tr>                  
                  <td><?php echo $tanggal;?></td>
                  <td><?php echo $inbox_idwb;?></td>
                  <td><?php echo $inbox_topik;?></td>
                  <td><?php echo $inbox_nama;?></td>
                  <?php if($inbox_author==''):?>
                        <td>Belum pernah diverifikasi (Laporan Baru)</td>
                  <?php else:?>
                        <td>Pernah diverifikasi, dibatalkan <b>[<?php echo $inbox_author;?>]</b> - <b>[<?php echo $tanggal_verif;?>]</b></td>
                  <?php endif;?>
                  
                  <td style="text-align:center; width:180px;">
                    <a class="popup2 btn-sm btn-success" data-toggle="modal" data-target="#ModalDetail<?php echo $inbox_id;?>">  <span class="fa fa-eye"></span></a> <a> &nbsp; | &nbsp;</a>
                    <a class="popup2 btn-sm btn-danger" data-toggle="modal" data-target="#ModalProses<?php echo $inbox_id;?>"><span class="fa fa-gears"></span> </a> <a> &nbsp; | &nbsp;</a>
                    <a class="popup2 btn-sm btn-info" data-toggle="modal" data-target="#ModalDisposisi<?php echo $inbox_id;?>"><span class="fa fa-send"></span> </a>
                   
                </tr>
				<?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong><?php echo date('Y');?> © Copyright <a href="http://tanjungbalaikota.go.id">Pemerintah Kota Tanjungbalai</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->



<?php foreach ($data->result_array() as $i) :
     $inbox_id=$i['inbox_id'];
     $inbox_idwb=$i['inbox_idwb'];
     $inbox_topik=$i['inbox_topik'];
     $inbox_tglkejadian=$i['inbox_tglkejadian'];
     $inbox_pejabat=$i['inbox_kategori_laporan'];
     $inbox_lokasi=$i['inbox_lokasi'];
     $inbox_kronologis=$i['inbox_kronologis'];
     $inbox_nama=$i['inbox_nama'];
     $inbox_email=$i['inbox_email'];
     $inbox_file=$i['inbox_file'];
     $tanggal=$i['tanggal'];

    ?>
  <!--Modal Edit Pengguna-->
        <div class="modal fade" id="ModalDetail<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Detail Laporan</h4>
                    </div>
                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDSK</label>
                        <div class="col-sm-8">
                      <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_idwb;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Lapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtgllapor" class="form-control" id="inputUserName" value="<?php echo $tanggal;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Pengaduan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Kategori Laporan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_pejabat;?>" readonly>
                        </div>
                    </div>

                    
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Kejadian</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_tglkejadian;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Uraian/Kronologis</label>
                        <div class="col-sm-8">
                        <textarea name="komentar" class="form-control" rows="15" cols="80" readonly><?php echo $inbox_kronologis;?></textarea>
                        
                        </div>
                    </div>
                    <br>
                    <hr>

                    <div class="form-group">
                        <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> DATA BUKTI PENGADUAN DARI PELAPOR</label>
                        
                         </div>
                         
                         <hr>
                        
                        <div class="col-sm-6">
                        <img width="570" height="550px" src="<?php echo base_url().'assets/files/'.$inbox_file;?>">

                        </div>
                    </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>

  <?php foreach ($data->result_array() as $i) :
     $inbox_id=$i['inbox_id'];
     $inbox_idwb=$i['inbox_idwb'];
     $inbox_topik=$i['inbox_topik'];
     $inbox_tglkejadian=$i['inbox_tglkejadian'];
     $inbox_pejabat=$i['inbox_kategori_laporan'];
     $inbox_lokasi=$i['inbox_lokasi'];
     $inbox_kronologis=$i['inbox_kronologis'];
     $inbox_nama=$i['inbox_nama'];
     $inbox_email=$i['inbox_email'];
     $inbox_file=$i['inbox_file'];
     $inbox_filetl=$i['inbox_filetl'];
     $tanggal=$i['tanggal'];

    ?>
  <!--Modal Proses Laporan-->
        <div class="modal fade" id="ModalProses<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Tindak Lanjut Laporan</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/inbox/simpan_penyelidikan'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDWB</label>
                        <div class="col-sm-8">
                        <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="hidden" name="filetl" value="<?php echo $inbox_filetl;?>">
                        <input type="hidden" name="xemail" value="<?php echo $inbox_email;?>">
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_idwb;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Lapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtgllapor" class="form-control" id="inputUserName" value="<?php echo $tanggal;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Pengaduan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtopik" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>

                  <hr>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> FORM HASIL VERIFIKASI & PENYELIDIKAN </label>
                        
                    </div>

                    <div class="form-group">
                      <label for="inputUserName" class="col-sm-3 control-label">Verifikasi</label>
                      <div class="col-sm-8">
                        <select class="form-control" name="xtindaklanjut" id="verif" required>
                            <option value="0">Pilih Status</option>
                            <option value="1">Setujui</option>
                            <option value="2">Tolak</option>
                        </select>
                      </div>
                  </div>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Verif</label>
                        <div class="col-sm-8">
                        <input type="text" name="xtanggalverif" class="form-control" id="inputUserName" value="<?php echo date("Y-m-d G:i:s")?>"readonly>
                        </div>
                  </div>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Keterangan</label>
                        <div class="col-sm-8">
                        <textarea name="xketerangan" class="form-control" rows="8" cols="80" ></textarea>
                        </div>
                  </div>

                   <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Upload Hasil Penyelidikan</label>
                        <div class="col-sm-8">
                            <input type="file" name="xfiletl" id="check"/>
                            </br>
                            <input type="file" name="xfiletl2" id="check2"/>
                            </br>
                            <input type="file" name="xfiletl3" id="check3"/>
                            </br>
                            </br>
                            <div class='alert alert-success'>Catatan: </br>
                            *File Hasil Penyelidikan, berupa gambar(jpg,jpeg,png) yang dapat menjelaskan hasil dari investigasi laporan. </br> 
                            *File Ukuran Maximal 2 Mb </div>
                        </div>

                    </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan"><span class="fa fa-thumbs-o-up"> </span> Simpan </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>


<?php foreach ($data->result_array() as $i) :
     $inbox_id=$i['inbox_id'];
     $inbox_idwb=$i['inbox_idwb'];
     $inbox_topik=$i['inbox_topik'];
     $inbox_tglkejadian=$i['inbox_tglkejadian'];
     $inbox_pejabat=$i['inbox_kategori_laporan'];
     $inbox_lokasi=$i['inbox_lokasi'];
     $inbox_kronologis=$i['inbox_kronologis'];
     $inbox_nama=$i['inbox_nama'];
     $inbox_email=$i['inbox_email'];
     $inbox_file=$i['inbox_file'];
     $inbox_filetl=$i['inbox_filetl'];
     $tanggal=$i['tanggal'];

    ?>
  <!--Modal Disposisi Laporan-->
        <div class="modal fade" id="ModalDisposisi<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Teruskan Laporan Ke OPD</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/inbox/disposisi_laporan'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDWB</label>
                        <div class="col-sm-8">
                        <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="hidden" name="filetl" value="<?php echo $inbox_file;?>">
                        <input type="hidden" name="xemail" value="<?php echo $inbox_email;?>">
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_idwb;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Lapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtgllapor" class="form-control" id="inputUserName" value="<?php echo $tanggal;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Pengaduan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtopik" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Kategori Laporan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtopik" class="form-control" id="inputUserName" value="<?php echo $inbox_pejabat;?>" readonly>
                        </div>
                    </div>

                  <hr>

                  <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> SILAHKAN TERUSKAN LAPORAN KE OPD </label>
                        
                    </div>

                    <div class="form-group">
                      <label for="inputUserName" class="col-sm-3 control-label">Pilih OPD</label>
                      <div class="col-sm-8">
                        <select class="form-control" name="xemail" required>
                            <option value="">-Pilih-</option>
                            <?php
                            $no=0;
                            foreach ($opd->result_array() as $o) :
                            $no++;
                            $opd_id=$o['opd_id'];
                            $opd_nama=$o['opd_nama'];
                            $opd_email=$o['opd_email'];
                            
                            ?>
                            <option value="<?php echo $opd_email;?>"><?php echo $opd_nama;?></option>
                            <?php endforeach;?>
                        </select>
                      </div>
                  </div>

                  <div class='alert alert-success'>Catatan: </br>
                            *Petugas Verifikasi diharapkan sebelum melakukan disposisi laporan agar berkoordinasi dengan pimpinan terkait wewenang dalam tindak lanjut laporan </br> 
                             </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan"><span class="fa fa-send"> </span> Kirim </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>



<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url().'assets/plugins/jQuery/jquery-2.2.3.min.js'?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js'?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url().'assets/plugins/datatables/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.min.js'?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url().'assets/plugins/slimScroll/jquery.slimscroll.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datepicker/bootstrap-datepicker.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.js'?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url().'assets/plugins/fastclick/fastclick.js'?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url().'assets/dist/js/app.min.js'?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url().'assets/dist/js/demo.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.js'?>"></script>
<!-- page script -->
<script>
//   $(function() {
//     $('input[type="file"]').prop('disabled', false);
//     $('#verif').on('input', function(e) {
//         if(this.value.length === "9") {
//             $('input[type="file"]').prop('disabled', false);
//         } else {
//             $('input[type="file"]').prop('disabled', true);
//         }
//     });
// });

$('[name="xtindaklanjut"]').change(function() {
  if ($(this).val() === "1")
    $('#check').removeAttr('disabled');
  else
    $('#check').attr('disabled', 'disabled');
});


$('[name="xtindaklanjut"]').change(function() {
  if ($(this).val() === "1")
    $('#check2').removeAttr('disabled');
  else
    $('#check2').attr('disabled', 'disabled');
});


$('[name="xtindaklanjut"]').change(function() {
  if ($(this).val() === "1")
    $('#check3').removeAttr('disabled');
  else
    $('#check3').attr('disabled', 'disabled');
});
</script>


<script>


  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": true
    });

    $('#datepicker').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('.datepicker3').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('.datepicker4').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $(".timepicker").timepicker({
      showInputs: true
    });

  });
</script>
<?php if($this->session->flashdata('msg')=='error'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Error',
                    text: "Password dan Ulangi Password yang Anda masukan tidak sama.",
                    showHideTransition: 'slide',
                    icon: 'error',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FF4859'
                });
        </script>

    <?php elseif($this->session->flashdata('msg')=='info'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: " Penyelidikan Berhasil di Simpan",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='sendmail'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: " Laporan Berhasil dikirim",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>      
    <?php elseif($this->session->flashdata('msg')=='success-hapus'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "Pesan Berhasil dihapus.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php else:?>

    <?php endif;?>
</body>
</html>
