<!--Counter Inbox-->
<?php
    $query=$this->db->query("SELECT * FROM tbl_inbox WHERE inbox_status='1'");
    $query2=$this->db->query("SELECT * FROM tbl_komentar WHERE komentar_status='0'");
    $jum_comment=$query2->num_rows();
    $jum_pesan=$query->num_rows();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sikomplit System | Hasil Penyelidikan</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="shorcut icon" type="text/css" href="<?php echo base_url().'theme/images/icon.png'?>">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css'?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css'?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/AdminLTE.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.css'?>">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datepicker/datepicker3.css'?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/skins/_all-skins.min.css'?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.css'?>"/>

</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

   <?php
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_menu_sidebar');
  ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sikomplit System | Data Hasil Penyelidikan
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Hasil Penyelidikan</li>
      </ol>
        <!-- Main content -->
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- <div class="callout callout-info">
          <h4>Halo, Operator !</h4>

          <p>Saya mengingatkan kepada operator, agar setiap laporan yang telah selesai diverifikasi agar mengirimkan kan hasil surat keterangan hasil investigasi atau penyelidikan ke email si pelapor, sebagai informasi tindak lanjut dari laporan si pelapor berikan. Terimakasih</p>
        </div>
 -->        <!-- /.box -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:12px;">
                <thead>
                <tr>
                    <th style="width:100px;">Tanggal Lapor</th>
                    <th style="width:70px;">ID Sikomplit</th>
                    <th style="width:100px;">Topik Laporan</th>
                    <th style="width:320px;">Keterangan Verifikasi</th>
                    <th style="width: 100px;">Petugas Verifikasi</th>
                    <th style="text-align:center; width:30px;">Progress</th>
                    <th style="text-align:center; width:40px;">Aksi</th>
                </tr>
                </thead>
                <tbody>
        <?php
          $no=0;
            foreach ($data->result_array() as $i) :
               $no++;
                       $inbox_id            =$i['inbox_id'];
                       $inbox_idwb          =$i['inbox_idwb'];
                       $inbox_topik         =$i['inbox_topik'];
                       $inbox_tglkejadian   =$i['inbox_tglkejadian'];
                       $inbox_pejabat       =$i['inbox_kategori_laporan'];
                       $inbox_lokasi        =$i['inbox_lokasi'];
                       $inbox_kronologis    =$i['inbox_kronologis'];
                       $inbox_nama          =$i['inbox_nama'];
                       $inbox_email         =$i['inbox_email'];
                       $inbox_file          =$i['inbox_file'];
                       $inbox_filetl        =$i['inbox_filetl'];
                       $inbox_author        =$i['inbox_author'];
                       $inbox_keterangan    =$i['inbox_keterangan'];
                       $inbox_tindaklanjut  =$i['inbox_tindaklanjut'];
                       $inbox_tanggal_verif =$i['inbox_tanggal_verif'];
                       $tanggal             =$i['inbox_tanggal'];

                    ?>
                <tr>
                  <td><?php echo $tanggal;?></td>
                  <td><?php echo $inbox_idwb;?></td>
                  <td><?php echo $inbox_topik;?></td>
                  <td><?php echo $inbox_keterangan;?></td>
                  <td><?php echo $inbox_author;?> [<?php echo $inbox_tanggal_verif;?>]</td>
                  <td style="text-align:center; width:40px;"><a class="popup2 btn-sm btn-primary with-arrow" data-toggle="modal" data-target="#ModalSK<?php echo $inbox_id;?>">  <span class="fa fa-gears"> </span></a></td>
                  
                  <td style="text-align:center; width:40px;">
                    <a class="popup2 btn-sm btn-success  with-arrow" data-toggle="modal" data-target="#ModalDetail<?php echo $inbox_id;?>">  <span class="fa fa-eye"></span></a><a> | </a>
                    <a class="popup2 btn-sm btn-danger  with-arrow" data-toggle="modal" data-target="#ModalBatal<?php echo $inbox_id;?>"><span class="fa fa-close"> </span></a> </td>  
                </tr>
        <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong><?php echo date('Y');?> © Copyright <a href="http://tanjungbalaikota.go.id">Pemerintah Kota Tanjungbalai</a>.</strong> All rights reserved.
  </footer>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->



<?php foreach ($data->result_array() as $i) :
     $inbox_id           =$i['inbox_id'];
     $inbox_idwb         =$i['inbox_idwb'];
     $inbox_topik        =$i['inbox_topik'];
     $inbox_tglkejadian  =$i['inbox_tglkejadian'];
     $inbox_pejabat      =$i['inbox_kategori_laporan'];
     $inbox_lokasi       =$i['inbox_lokasi'];
     $inbox_kronologis   =$i['inbox_kronologis'];
     $inbox_nama         =$i['inbox_nama'];
     $inbox_email        =$i['inbox_email'];
     $inbox_file         =$i['inbox_file'];
     $inbox_filetl       =$i['inbox_filetl'];
     $inbox_filetl2      =$i['inbox_filetl2'];
     $inbox_filetl3      =$i['inbox_filetl3'];
     $inbox_author       =$i['inbox_author'];
     $inbox_keterangan   =$i['inbox_keterangan'];
     $inbox_tindaklanjut =$i['inbox_tindaklanjut'];


    ?>
  <!--Modal Edit Pengguna-->
        <div class="modal fade" id="ModalSK<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hasil Tindak Lanjut</h4>
                    </div>
                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDSK</label>
                        <div class="col-sm-8">
                      <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_idwb;?>" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Pengaduan</label>
                        <div class="col-sm-8">
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group">
                        <div class="form-group">
                         
                        <label for="inputUserName" class="col-sm-8 control-label"> DATA HASIL FOLLOW UP OPD</label>
                        
                         </div>
                    <hr>
                        <div class="col-sm-8">
                        <img width="570" height="550px" src="<?php echo base_url().'assets/resolve/'.$inbox_filetl;?>">

                        </div>
                        <br><hr><br>
                        <div class="col-sm-8">
                        <img width="570" height="550px" src="<?php echo base_url().'assets/resolve/'.$inbox_filetl2;?>">

                        </div>
                        <br>&nbsp;<br>
                        <div class="col-sm-8">
                        <img width="570" height="550px" src="<?php echo base_url().'assets/resolve/'.$inbox_filetl3;?>">

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Keterangan :</label>
                        <div class="col-sm-9">
                        <textarea name="komentar" class="form-control" rows="15" cols="300" readonly><?php echo $inbox_keterangan;?></textarea>
                        
                        </div>
                    </div>
                    
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Tutup</button>
                        
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>

  <?php foreach ($data->result_array() as $i) :
     $inbox_id          =$i['inbox_id'];
     $inbox_idwb        =$i['inbox_idwb'];
     $inbox_topik       =$i['inbox_topik'];
     $inbox_tglkejadian =$i['inbox_tglkejadian'];
     $inbox_pejabat     =$i['inbox_kategori_laporan'];
     $inbox_lokasi      =$i['inbox_lokasi'];
     $inbox_kronologis  =$i['inbox_kronologis'];
     $inbox_nama        =$i['inbox_nama'];
     $inbox_email       =$i['inbox_email'];
     $inbox_file        =$i['inbox_file'];
     $tanggal           =$i['tanggal'];

    ?>
  <!--Modal Edit Pengguna-->
        <div class="modal fade" id="ModalDetail<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Detail Laporan Pelapor</h4>
                    </div>
                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Nama Pelapor</label>
                        <div class="col-sm-8">
                      <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_nama;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Email Pelapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtgllapor" class="form-control" id="inputUserName" value="<?php echo $inbox_email;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Pengaduan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Kategori Laporan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_pejabat;?>" readonly>
                        </div>
                    </div>

                    
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Tanggal Kejadian</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_tglkejadian;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Uraian/Kronologis</label>
                        <div class="col-sm-8">
                        <textarea name="komentar" class="form-control" rows="15" cols="80" readonly><?php echo $inbox_kronologis;?></textarea>
                        
                        </div>
                    </div>
                    <hr>

                    <div class="form-group">
                        <div class="form-group">
                        <label for="inputUserName" class="col-sm-9 control-label"> DATA BUKTI PENGADUAN DARI PELAPOR</label>
                        
                         </div>
                         
                         <hr>
                        
                        <div class="col-sm-6">
                        <img width="570" height="550px" src="<?php echo base_url().'assets/files/'.$inbox_file;?>">

                        </div>
                    </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Tutup</button>
                        
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>


  <?php foreach ($data->result_array() as $i) :
     $inbox_id            =$i['inbox_id'];
     $inbox_idwb          =$i['inbox_idwb'];
     $inbox_topik         =$i['inbox_topik'];
     $inbox_tglkejadian   =$i['inbox_tglkejadian'];
     $inbox_pejabat       =$i['inbox_kategori_laporan'];
     $inbox_lokasi        =$i['inbox_lokasi'];
     $inbox_kronologis    =$i['inbox_kronologis'];
     $inbox_nama          =$i['inbox_nama'];
     $inbox_email         =$i['inbox_email'];
     $inbox_file          =$i['inbox_file'];
     $inbox_filetl        =$i['inbox_filetl'];
     $inbox_tanggal_verif =$i['inbox_tanggal_verif'];

    ?>
  <!--Modal Batal Laporan-->
        <div class="modal fade" id="ModalBatal<?php echo $inbox_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Anda Yakin Batalkan Data Penyelidikan ini?</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/inbox/batalkan_penyelidikan'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                
                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">IDWB</label>
                        <div class="col-sm-8">
                        <input type="hidden" name="kode" value="<?php echo $inbox_id;?>"/> 
                        <input type="hidden" name="filetl" value="<?php echo $inbox_filetl;?>">
                        <input type="hidden" name="xtanggalverif" value="<?php echo $inbox_tanggal_verif;?>">
                        <input type="text" name="xidwb" class="form-control" id="inputUserName" value="<?php echo $inbox_idwb;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Topik Laporan</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xtopik" class="form-control" id="inputUserName" value="<?php echo $inbox_topik;?>" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputUserName" class="col-sm-3 control-label">Nama Pelapor</label>
                        <div class="col-sm-8">
                       
                        <input type="text" name="xnama" class="form-control" id="inputUserName" value="<?php echo $inbox_nama;?>" readonly>
                        </div>
                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger btn-flat" id="simpan"><span class="fa fa-times-circle"> </span> Batalkan Verifikasi </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>




<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url().'assets/plugins/jQuery/jquery-2.2.3.min.js'?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js'?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url().'assets/plugins/datatables/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.min.js'?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url().'assets/plugins/slimScroll/jquery.slimscroll.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datepicker/bootstrap-datepicker.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/timepicker/bootstrap-timepicker.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/daterangepicker/daterangepicker.js'?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url().'assets/plugins/fastclick/fastclick.js'?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url().'assets/dist/js/app.min.js'?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url().'assets/dist/js/demo.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.js'?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

    $('#datepicker').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('.datepicker3').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $('.datepicker4').datepicker({
      autoclose: true,
      format: 'yyyy-mm-dd'
    });
    $(".timepicker").timepicker({
      showInputs: true
    });

  });
</script>
<?php if($this->session->flashdata('msg')=='error'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Error',
                    text: "Password dan Ulangi Password yang Anda masukan tidak sama.",
                    showHideTransition: 'slide',
                    icon: 'error',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FF4859'
                });
        </script>

    <?php elseif($this->session->flashdata('msg')=='info'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: " Penyelidikan Berhasil di Batalkan",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='success-hapus'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "Pesan Berhasil dihapus.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php else:?>

    <?php endif;?>
</body>
</html>
