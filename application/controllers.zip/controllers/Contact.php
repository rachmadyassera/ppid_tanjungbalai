<?php
class Contact extends CI_Controller{
  function __construct(){
		parent::__construct();
      $this->load->model('m_kontak');
      $this->load->model('m_pengunjung');
      $this->load->library('upload');
  		$this->m_pengunjung->count_visitor();
	}
	function index(){
      $x['data']=$this->m_kontak->get_all_wb();
		  $this->load->view('depan/v_check',$x);
	}

  // function kirim_pesan(){
  //     $topik=htmlspecialchars($this->input->post('xtopik',TRUE),ENT_QUOTES);
  //     $tglkejadian=htmlspecialchars($this->input->post('xtglkejadian',TRUE),ENT_QUOTES);
  //     $pejabat=htmlspecialchars($this->input->post('xpejabat',TRUE),ENT_QUOTES);
  //     $lokasi=htmlspecialchars($this->input->post('xlokasi',TRUE),ENT_QUOTES);
  //     $kronologis=htmlspecialchars($this->input->post('xkronologis',TRUE),ENT_QUOTES);
  //     $email=htmlspecialchars($this->input->post('xemail',TRUE),ENT_QUOTES);
  //     $nama=htmlspecialchars($this->input->post('xnama',TRUE),ENT_QUOTES);
  //     $file=htmlspecialchars($this->input->post('xfile',TRUE),ENT_QUOTES);
  //     $this->m_kontak->kirim_pesan($nama,$email,$kontak,$pesan);
  //     echo $this->session->set_flashdata('msg','<p><strong> NB: </strong> Terima Kasih Telah Menghubungi Kami.</p>');
  //     redirect('contact');
  // }
  // 
  
  function valid_nik(){
      $nik=strip_tags(str_replace("'", "", $this->input->post('nik')));
      $n=$nik;
      $cnik=$this->m_kontak->ceknik($n);
      if($cnik->num_rows() > 0){
        $this->session->set_userdata('nik',$n);
        $xcnik=$cnik->row_array();
        $nik=$xcnik['nik'];
        $nama=$xcnik['nama_pelapor'];
        $x['nik']=$xcnik;
        $x['data']=$this->m_kontak->get_all_wb();
        $this->load->view('depan/v_contact',$x);

      }else{
      echo $this->session->set_flashdata('msg',"<div class='alert alert-warning'>'Tidak dapat Melanjutkan Proses Pengaduan, NIK Anda tidak terdaftar atau salah, mohon periksa kembali.</div>");
              redirect('');
      }
    }

  function get_wb(){
    $id=$this->uri->segment(3);
    $get_db=$this->m_kontak->get_all_wb($id);
    $q=$get_db->row_array();
    $file=$q['file_data'];
    $path='./assets/files/'.$file;
    $data = file_get_contents($path);
    $name = $file;
    force_download($name, $data);
  }

  function kirim_pesan(){
        $config['upload_path'] = './assets/files/'; //path folder
        $config['allowed_types'] = 'jpg|jpeg|png|pdf|zip|rar'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //nama yang terupload nantinya
        $config['max_size'] = 10240000;

        $this->upload->initialize($config);
        // if ($size < 10240000 AND $type == $config['allowed_types'] ) {
          if(!empty($_FILES['xfile']['name']))
          {
            if ($this->upload->do_upload('xfile')){
                $gbr = $this->upload->data();
                $file=$gbr['file_name'];
                $topik=htmlspecialchars($this->input->post('xtopik',TRUE),ENT_QUOTES);
                $tglkejadian=htmlspecialchars($this->input->post('xtglkejadian',TRUE),ENT_QUOTES);
                $pejabat=htmlspecialchars($this->input->post('xpejabat',TRUE),ENT_QUOTES);
                $lokasi=htmlspecialchars($this->input->post('xlokasi',TRUE),ENT_QUOTES);
                $kronologis=htmlspecialchars($this->input->post('xkronologis',TRUE),ENT_QUOTES);
                $email=htmlspecialchars($this->input->post('xemail',TRUE),ENT_QUOTES);
                $nama=htmlspecialchars($this->input->post('xnama',TRUE),ENT_QUOTES);
                $idwb=htmlspecialchars($this->input->post('xidwb',TRUE),ENT_QUOTES);
                //$file=htmlspecialchars($this->input->post('xfile',TRUE),ENT_QUOTES);
                  $this->m_kontak->kirim_pesan($topik,$tglkejadian,$pejabat,$lokasi,$kronologis,$email,$nama,$idwb,$file);

                  echo $this->session->set_flashdata('msg',"<div class='alert alert-info'><p><strong> NB: </strong> Terima Kasih Telah Memberikan Laporan Kepada Kami, <b>Untuk Tindak Lanjut Akan kami beritahukan ke Email yang anda Daftarkan.</b></p></div>");

                  $from_email = "sikomplit.tjb@gmail.com"; 
                  $to_email = $this->input->post('xemail');; 
                  
                  $config = Array(
                  'protocol' => 'smtp',
                  'smtp_host' => 'ssl://smtp.googlemail.com',
                  'smtp_port' => 465,
                  'smtp_user' => $from_email,
                  'smtp_pass' => 'sikomplit20@TJB',
                  'mailtype'  => 'html', 
                  'charset'   => 'iso-8859-1'
                  );
                  
                  $idwb=$this->input->post('xidwb');
                  $xidsendmail = 'Sikomplit Notify | '.$idwb;
                  $x['data']=$this->m_kontak->get_lapor_byidwb($idwb);
                  $message=$this->load->view('template-email/notif_mail',$x,TRUE);
                  $this->load->library('email', $config);
                  $this->email->set_newline("\r\n");   
                  $this->email->from($from_email, 'Sikomplit | Notify - Please No Reply'); 
                  $this->email->to($to_email);
                  $this->email->subject($xidsendmail); 
                  $this->email->message($message); 
                  $this->email->send();
                //session_destroy();
                redirect('');
              }else{
              echo $this->session->set_flashdata('msg',"<div class='alert alert-warning'>'Laporan Tidak Dapat diProses, Data yang anda kirim Belum Benar'</div>");
              redirect('');
              }

              }else{
              echo $this->session->set_flashdata('msg',"<div class='alert alert-warning'>'Laporan Tidak Dapat diProses, Data yang anda kirim Belum Benar' Atau File yang anda Upload tidak sesuai .</div>");
              redirect('');
              }

        // }else{
            // echo "Gagal Upload File";
        // }

        
        
  }
}
