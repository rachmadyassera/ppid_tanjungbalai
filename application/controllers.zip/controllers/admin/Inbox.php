<?php
class Inbox extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
		$this->load->model('m_kontak');
		$this->load->model('m_pengguna');
		$this->load->model('m_opd');
		$this->load->library('upload');
	}

	function index(){
		$this->m_kontak->update_status_kontak_0();
		$x['data']=$this->m_kontak->get_all_inbox_0();
		$x['opd']=$this->m_opd->get_all_opd();
		$this->load->view('admin/v_inbox',$x);
	}

	function hasil_lidik(){
		$this->m_kontak->update_status_kontak_1();
		$x['data']=$this->m_kontak->get_all_inbox_1();
		$this->load->view('admin/v_hasil_lidik',$x);
	}

	function verif_ditolak(){
		// $this->m_kontak->update_status_kontak_2();
		$x['data']=$this->m_kontak->get_all_inbox_2();
		$this->load->view('admin/v_verif_tolak',$x);
	}

	function hapus_inbox(){
		$kode=$this->input->post('kode');
		$this->m_kontak->hapus_kontak($kode);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/inbox');
	}

	function simpan_penyelidikan(){

		$data = array();
		$config['upload_path'] = './assets/resolve/'; //path folder
        $config['allowed_types'] = 'jpg|jpeg|png|pdf|xps|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //nama yang terupload nantinya


         $this->load->library('upload', $config);
         $this->upload->initialize($config);

	    	if(!empty($_FILES['xfiletl']['name']) && !empty($_FILES['xfiletl2']['name']) && !empty($_FILES['xfiletl3']['name'])){
		    
				    if (!$this->upload->do_upload('xfiletl')) { //upload image 1
					    $error = array('error' => $this->upload->display_errors());
					}else{
					    $fileData = $this->upload->data();
					    $data['xfiletl'] = $fileData['file_name'];
					    
					}

					if (!$this->upload->do_upload('xfiletl2')) { //upload image 2
					    $error = array('error' => $this->upload->display_errors()); 
					}else{
					    $fileData = $this->upload->data();
					    $data['xfiletl2'] = $fileData['file_name'];
					}

					if (!$this->upload->do_upload('xfiletl3')) { //upload image 2
					    $error = array('error' => $this->upload->display_errors()); 
					}else{
					    $fileData = $this->upload->data();
					    $data['xfiletl3'] = $fileData['file_name'];
					}

					$img_1=$data['xfiletl'];
					$img_2=$data['xfiletl2'];
					$img_3=$data['xfiletl3'];
					$id=$this->input->post('kode');
                    
                    $tindaklanjut=strip_tags($this->input->post('xtindaklanjut'));
					$keterangan=$this->input->post('xketerangan');
					$kode=$this->session->userdata('idadmin');
					$user=$this->m_pengguna->get_pengguna_login($kode);
					$p=$user->row_array();
					$user_id=$p['pengguna_id'];
					$user_nama=$p['pengguna_nama'];
					$tanggal_verif=$this->input->post('xtanggalverif');
					// $data=$this->input->post('filetl');
					// $path='./assets/resolve/'.$data;
					// unlink($path);
					// 
					//var_dump($img_1,$img_2,$img_3);
					
					
					$this->m_kontak->simpan_penyelidikan($id,$tindaklanjut,$keterangan,$img_1,$img_2,$img_3,$user_nama,$tanggal_verif);
					echo $this->session->set_flashdata('msg','info');

					
					$from_email = "sikomplit.tjb@gmail.com"; 
					$to_email = $this->input->post('xemail');; 
					
					$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => $from_email,
					'smtp_pass' => 'sikomplit20@TJB',
					'mailtype'  => 'html', 
					'charset'   => 'iso-8859-1'
					);
					
					$idwb=$this->input->post('xidwb');
					$xidsendmail = 'Sikomplit Progres | '.$idwb;
					$id=$this->input->post('kode');
					$x['data']=$this->m_kontak->get_lapor_byid($id);
					$message=$this->load->view('template-email/send_mail',$x,TRUE);
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");   
					$this->email->from($from_email, 'Sikomplit | No Replay'); 
					$this->email->to($to_email);
					$this->email->subject($xidsendmail); 
					$this->email->message($message); 
					$this->email->send();
					redirect('admin/inbox');
            
        }else{
				$id=$this->input->post('kode');
                $tindaklanjut=strip_tags($this->input->post('xtindaklanjut'));
				$keterangan=$this->input->post('xketerangan');
				$kode=$this->session->userdata('idadmin');
				$user=$this->m_pengguna->get_pengguna_login($kode);
				$p=$user->row_array();
				$user_id=$p['pengguna_id'];
				$user_nama=$p['pengguna_nama'];
				$tanggal_verif=$this->input->post('xtanggalverif');
				$this->m_kontak->simpan_tolak_penyelidikan($id,$tindaklanjut,$keterangan,$user_nama,$tanggal_verif);
				echo $this->session->set_flashdata('msg','info');
				
        }

	}

	function disposisi_laporan(){

		$from_email = "sikomplit.tjb@gmail.com";//sikomplit@tanjungbalaikota.go.id 
		$to_email = $this->input->post('xemail');
		
		$config = Array(
		'protocol' => 'smtp',
		'smtp_host' => 'ssl://smtp.gmail.com',//mail.tanjungbalaikota.go.id
		'smtp_port' => 465,
		'smtp_user' => $from_email,
		'smtp_pass' => 'sikomplit20@TJB',
		'mailtype'  => 'html', 
		'charset'   => 'iso-8859-1'
		);
		
		$idwb=$this->input->post('xidwb');
		$xidsendmail = 'Sikomplit Follow Up | '.$idwb;
		$id=$this->input->post('kode');
		$x['data']=$this->m_kontak->get_lapor_byid($id);
		$message=$this->load->view('template-email/opd_mail',$x,TRUE);
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");   
		$this->email->from($from_email, 'Sikomplit | No Replay'); 
		$this->email->to($to_email);
		$this->email->subject($xidsendmail); 
		$this->email->message($message); 
		// var_dump($x);

		$this->email->send();
		echo $this->session->set_flashdata('msg','sendmail');
		redirect('admin/inbox');

	}

	function batalkan_penyelidikan(){
		$id=$this->input->post('kode');
		$data=$this->input->post('filetl');
		$path='./assets/resolve/'.$data;
		unlink($path);
        $tindaklanjut=(0);
		$keterangan=$this->input->post('');
		$file=$this->input->post('');
		$kode=$this->session->userdata('idadmin');
		$user=$this->m_pengguna->get_pengguna_login($kode);
		$p=$user->row_array();
		$user_id=$p['pengguna_id'];
		$user_nama=$p['pengguna_nama'];
		$tanggal_verif=$this->input->post('xtanggalverif');
		// $data=$this->input->post('filetl');
		// $path='./assets/resolve/'.$data;
		// unlink($path);
		$this->m_kontak->batal_penyelidikan($id,$tindaklanjut,$keterangan,$file,$user_nama,$tanggal_verif);
		echo $this->session->set_flashdata('msg','info');
		redirect('admin/inbox/');

		}
}
